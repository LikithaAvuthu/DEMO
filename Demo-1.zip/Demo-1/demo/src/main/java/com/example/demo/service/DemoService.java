package com.example.demo.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Cell;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.demo.model.DemoModel;


@Service
public class DemoService {

	
	List<DemoModel> list= new ArrayList<DemoModel>();

	public List<DemoModel> findAll() {
		// TODO Auto-generated method stub
		
		//DemoModel demo;
		//StringBuilder str = new StringBuilder();
		XSSFWorkbook myExcelBook;
		try {
			myExcelBook = new XSSFWorkbook(new FileInputStream("input.xlsx"));
			String sheetName = myExcelBook.getSheetName(0);
		    XSSFSheet myExcelSheet = myExcelBook.getSheet(sheetName);
		    //Iterator<Row> rows= myExcelSheet.iterator();
		   // rows.next();
	    System.out.println("Inside details");
		    for(Row row:myExcelSheet)
		    {
		    	if(row.getRowNum()==0)
		    	{
		    		continue;
		    	}
		    	if(row.getCell(0).getCellType()==CellType.BLANK) {

		    	    break;

		    	    }
		    	DemoModel demo =new DemoModel(row.getCell(0).toString(),(long)row.getCell(1).getNumericCellValue(),row.getCell(2).getNumericCellValue(),
		    												row.getCell(3).toString(),row.getCell(4).toString(),row.getCell(5).toString(),row.getCell(6).toString());
		    	System.out.println("Demo:"+demo.toString());
		    	list.add(demo);
		    	
		    	
		    }
		
		
		//return detailsService.findAll();
		} catch(IOException e){
			e.printStackTrace();
		}
		return list;// should return a list
			
		}
	
	
	public boolean saveDataFromForm(DemoModel demo) {// long app id;,double appVersion,String appType,String msiPath,boolean trigger
		
		boolean isflag=false;
		//StringBuilder str = new StringBuilder();
		//String Array[] = strdetails.split(",");
		XSSFWorkbook myExcelBook;
		try {
			FileInputStream file=new FileInputStream("input.xlsx");
			myExcelBook = new XSSFWorkbook(file);
			String sheetName = myExcelBook.getSheetName(0);
		    XSSFSheet myExcelSheet = myExcelBook.getSheet(sheetName);
		
		    // row and columns    
		   XSSFRow row;
		    XSSFCell cells;

		   // int rowCount = myExcelSheet.getLastRowNum();
		    //Iterator<Row> rows= myExcelSheet.iterator();
		    int newRow=0;
		    for(Row r :myExcelSheet) {
		    	
		    	if(r.getCell(0).getCellType()==CellType.BLANK) {
	    			newRow=r.getRowNum();
		    		break;
	    		}
		    	
		    }
		    row=myExcelSheet.createRow(newRow);
		    cells=row.createCell(0);
		    cells.setCellValue(demo.getAppName());
		    cells=row.createCell(1);
		    cells.setCellValue(demo.getAppId());
		    cells=row.createCell(2);
		    cells.setCellValue(demo.getAppVersion());
		    cells=row.createCell(3);
		    cells.setCellValue(demo.getAppType());
		    cells=row.createCell(4);
		    cells.setCellValue(demo.getMsiPath());
		    cells=row.createCell(5);
		    cells.setCellValue(demo.getOs());
		    cells=row.createCell(6);
		    cells.setCellValue(demo.isTrigger());
		    
		    System.out.println("Afetr row creation ");
		    
		  	//myExcelBook.close();
		  	file.close();
		  	FileOutputStream outFile = new FileOutputStream(new File("input.xlsx"));
	        myExcelBook.write(outFile);
	        
	        outFile.close();
	        isflag=true;
	        

			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch blocks
				e.printStackTrace();
				throw new NoSuchElementException()  ;
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return isflag;
	}


	
	public DemoModel findByName(String appName) {
		
			DemoModel demo=null;
			// TODO Auto-generated method stub
			//StringBuilder str = new StringBuilder();
			XSSFWorkbook myExcelBook;
			try {
				myExcelBook = new XSSFWorkbook(new FileInputStream("input.xlsx"));
				String sheetName = myExcelBook.getSheetName(0);
			    XSSFSheet myExcelSheet = myExcelBook.getSheet(sheetName);
			    //Iterator<Row> rows= myExcelSheet.iterator();
				   // rows.next();
				    for(Row row:myExcelSheet)
				    {

				    	if(row.getRowNum()==0)
				    	{
				    		continue;
				    	}
				    	if(row.getCell(0).getCellType()== CellType.BLANK) {
			    			
				    		break;
			    		}
				    	if(row.getCell(0).toString().equals(appName))
				    	{
				    		 demo =new DemoModel(row.getCell(0).toString(),(long)row.getCell(1).getNumericCellValue(),row.getCell(2).getNumericCellValue(),
									row.getCell(3).toString(),row.getCell(4).toString(),row.getCell(5).toString(),row.getCell(6).toString());
				    	
				    			break;
				    	}
				    	
				    	
				    		
				    }
				    
			  //	myExcelBook.close();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			return demo;
	}

	public boolean putDetails(String appName) {
		// TODO Auto-generated method stub
		
		boolean isFlag =false;
		XSSFWorkbook myExcelBook;
		try {
			FileInputStream file=new FileInputStream("input.xlsx");
			myExcelBook = new XSSFWorkbook(file);
			String sheetName = myExcelBook.getSheetName(0);
		    XSSFSheet myExcelSheet = myExcelBook.getSheet(sheetName);
		
		    // row and columns    
		    XSSFRow row;
		    //XSSFCell cells;

		    int rowCount = myExcelSheet.getLastRowNum();
		   // int colCount = myExcelSheet.getRow(0).getLastCellNum();
		    for(int r = 0; r < rowCount; r++) {
		    	row = myExcelSheet.getRow(r);
		    	/*if(row.getPhysicalNumberOfCells() == 0){
	    		break;
		    	}*/
		    	if(row.getCell(0).getCellType()==CellType.BLANK) {
	    			break;
	    		}
		    	
		    	if(row.getCell(0).toString().equals(appName)) {
		    		
		    		if(row.getCell(6).toString().equals("Yes"))
		    			row.getCell(6).setCellValue("No");
		    		
		    		if(row.getCell(6).toString().equals("No"))
		    			 row.getCell(6).setCellValue("Yes");
		    		
		    		isFlag=true;
		    		
		    		System.out.println("delete");
		    		System.out.println("Values:"+row.toString());
		    		 //int lastRowNum = myExcelSheet.getLastRowNum();
		    	       
		    	                
		    	            
		    	        }
		    		
		    		
		    	
		    	
	           }
		    
		  	//myExcelBook.close();
		  	//file.close();
		  	FileOutputStream outFile = new FileOutputStream(new File("input.xlsx"));
	        myExcelBook.write(outFile);
	        outFile.close();

			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return isFlag;
	}

	public boolean delete(String appName) {
		// TODO Auto-generated method stub
		boolean isflag=false;
		//StringBuilder str = new StringBuilder();
		XSSFWorkbook myExcelBook;
		try {
			FileInputStream file=new FileInputStream("input.xlsx");
			myExcelBook = new XSSFWorkbook(file);
			String sheetName = myExcelBook.getSheetName(0);
		    XSSFSheet myExcelSheet = myExcelBook.getSheet(sheetName);
		
		    // row and columns    
		    XSSFRow row;
		  //  XSSFCell cells;

		    int rowCount = myExcelSheet.getLastRowNum();
		   // int colCount = myExcelSheet.getRow(0).getLastCellNum();
		    for(int r = 0; r < rowCount; r++) {
		    	row = myExcelSheet.getRow(r);
		    	
		    	if(row.getCell(0).getCellType()==CellType.BLANK) {
	    			break;
	    		}
		    	
		    	if(row.getCell(0).toString().equals(appName)) {
		    		System.out.println("delete");
		    		System.out.println("Values:"+row.toString());
		    		
		    	        if (r >= 0 && r < rowCount) {
		    	            myExcelSheet.shiftRows(r + 1, rowCount, -1);
		    	        }
		    	        if (r == rowCount) {
		    	            XSSFRow removingRow=myExcelSheet.getRow(r);
		    	            if(removingRow != null) {
		    	                myExcelSheet.removeRow(removingRow);
		    	                isflag=true;
		    	                
		    	            }
		    	        }
		    		
		    		
		    	
		    	
	           }
		    }
		  	
		  	file.close();
		  	FileOutputStream outFile = new FileOutputStream(new File("input.xlsx"));
	        myExcelBook.write(outFile);
	        outFile.close();

			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return isflag;
		
	}

	
	
	
		
	



	
	}


