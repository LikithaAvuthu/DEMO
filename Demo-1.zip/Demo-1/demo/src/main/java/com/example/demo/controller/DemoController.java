package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.model.DemoModel;
import com.example.demo.service.DemoService;


@RestController
@RequestMapping("/Win")
public class DemoController {

	
	
	
		
		
		@Autowired private DemoService demoService;
		
		/* @RequestMapping("/")
		   public String index() {
		      return "details";
		   }*/
		
		@GetMapping(value="/getDetails")
		public List<DemoModel> home(Model model)
		{   
			List<DemoModel> demoModel= demoService.findAll();
			//model.addAttribute("detail",new DemoModel());
			//Details details= detailsService.findAll();
			//model.addAttribute("details", details);
			return demoModel; //returns ui page
		}
		
		
		@GetMapping("/getDetails/{appName}")
		public DemoModel getDetailsByName(@PathVariable("appName") String appname)
		{
			
			 DemoModel details= demoService.findByName(appname);
			//model.addAttribute("details", details);
			return details;
		}
		
		
		
		@PutMapping("/putDetails/{name}")
		public ResponseEntity<String> putDetails( @PathVariable("name") String appName) {
			
			
			boolean status=demoService.putDetails(appName);
			
			final HttpHeaders httpHeaders= new HttpHeaders();
		    httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		    return new ResponseEntity<String>("{\"Status\": \""+ status+"\" }", httpHeaders, HttpStatus.OK);
			
			
		    
		   // return new ResponseEntity<String>("{\"test\": \"jsonResponseExample\"}" , httpHeaders, HttpStatus.OK);
			
		/*	if(status== true)
				return new ResponseEntity<String>(HttpStatus.OK);
			else
				return new ResponseEntity<String>(HttpStatus.NOT_MODIFIED);
			*/

			


			

		    
		     
		      
		  }

		 @DeleteMapping("/deleteDetails/{name}")
		 public ResponseEntity<String> deleteEmployee(@PathVariable("name") String appName) {
		    
			 boolean status=demoService.delete(appName);
			 
		    
		    final HttpHeaders httpHeaders= new HttpHeaders();
		    httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		    return new ResponseEntity<String>("{\"Status\": \""+ status+"\" }", httpHeaders, HttpStatus.OK);
		  }
		
		
		
		
		
		
		@PostMapping(value="/postDetails")
		public ResponseEntity<String> uploadDetails(@RequestBody DemoModel demo)
		{
			boolean isFlag= demoService.saveDataFromForm(demo);
			final HttpHeaders httpHeaders= new HttpHeaders();
		    httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		    return new ResponseEntity<String>("{\"Status\": \""+ isFlag+"\" }", httpHeaders, HttpStatus.OK);
			/*if(isFlag)
			{
				redirectattributes.addFlashAttribute("successmessage","Details added to the file Successfully!");
			}
			else
			{
				redirectattributes.addFlashAttribute("failuremessage","Details couldn't be added to the file.Please Try Again!");
			}
			
			return "redirect:/details";*/
		}
}
	

	
